# Player from 10,000 Years — Offline Android with Permanent Native History

This project keeps the stable WhatPiece-style game/database and moves completed-round history/state persistence into a native SQLite database inside the Android app.

## Design
- Fully offline: no INTERNET permission.
- Game UI/database remain in `app/src/main/assets/index.html`.
- Native SQLite database: `tenk_history.db`.
- Native table `kv` stores game state, history, and recent-character data as JSON blobs.
- JavaScript bridge is exposed as `AndroidHistory`.
- Existing JSON Backup/Restore remains available.
- Existing history key is preserved as `tenk-dle-v3_history` for compatibility with the stable game.
- Database is private to the Android app and survives normal app close/reopen.

## Important
This is an Android Studio source project. An Android build environment is required to produce the installable APK. The project has been checked for JavaScript syntax, but an APK was not compiled in the current environment because the Android SDK/Gradle toolchain is unavailable here.
