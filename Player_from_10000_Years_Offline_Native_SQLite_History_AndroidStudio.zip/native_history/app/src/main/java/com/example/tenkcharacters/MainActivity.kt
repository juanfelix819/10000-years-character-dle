package com.example.tenkcharacters

import android.annotation.SuppressLint
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var game: WebView
    private lateinit var db: HistoryDb

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = HistoryDb(this)
        window.statusBarColor = Color.rgb(11, 14, 19)
        window.navigationBarColor = Color.rgb(11, 14, 19)

        game = WebView(this).apply {
            setBackgroundColor(Color.rgb(11, 14, 19))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = false
                allowFileAccessFromFileURLs = false
                allowUniversalAccessFromFileURLs = false
                cacheMode = WebSettings.LOAD_NO_CACHE
                builtInZoomControls = false
                displayZoomControls = false
            }
            addJavascriptInterface(AndroidHistory(), "AndroidHistory")
            webChromeClient = WebChromeClient()
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(game)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (game.canGoBack()) game.goBack() else finish()
            }
        })
    }

    inner class AndroidHistory {
        @JavascriptInterface fun put(key: String, value: String) = db.put(key, value)
        @JavascriptInterface fun get(key: String): String? = db.get(key)
        @JavascriptInterface fun remove(key: String) = db.remove(key)
    }

    override fun onResume() { super.onResume(); game.onResume() }
    override fun onPause() { game.onPause(); super.onPause() }
    override fun onDestroy() { game.stopLoading(); game.destroy(); db.close(); super.onDestroy() }
}

private class HistoryDb(context: android.content.Context) : SQLiteOpenHelper(context, "tenk_history.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE kv (key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    @Synchronized fun put(key: String, value: String) {
        val cv = ContentValues().apply { put("key", key); put("value", value) }
        writableDatabase.insertWithOnConflict("kv", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }
    @Synchronized fun get(key: String): String? {
        readableDatabase.query("kv", arrayOf("value"), "key=?", arrayOf(key), null, null, null).use { c ->
            return if (c.moveToFirst()) c.getString(0) else null
        }
    }
    @Synchronized fun remove(key: String) { writableDatabase.delete("kv", "key=?", arrayOf(key)) }
}
